import hm_10_分隔线模块

hm_10_分隔线模块.print_line("-",50)
print(hm_10_分隔线模块.name)